﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMI_QtToWPF.ViewModel;

namespace HMI_QtToWPF.ViewModel;

public partial class TimeInputVM : NavigationBaseVM
{
	public TimeInputVM()
	{
		this.PageName = " TimeInputVM";
	}
}
