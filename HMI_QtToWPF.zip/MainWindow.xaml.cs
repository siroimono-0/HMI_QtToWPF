﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using HMI_QtToWPF.ViewModel;

namespace HMI_QtToWPF;

/// <summary>
/// Interaction logic for MainWindow.xaml
/// </summary>
public partial class MainWindow : Window
{
    MainWindowVM? vm = null;
    public MainWindow(MainWindowVM vm)
    {
        InitializeComponent();
        this.vm = vm;
        this.DataContext = this.vm;
    }
}